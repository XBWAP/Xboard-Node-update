# VmqPay - V免签 支付插件

对接 V免签(vmqphp) 的 Xboard 支付插件,仅支持下单跳转 + 异步回调,不含补单。

## 安装
1. 将 `VmqPay` 目录放入 Xboard 的 `plugins/` 下(Docker 部署需确保目录被挂载或重建进镜像)。
2. 后台 插件管理 安装并启用。
3. 后台 支付配置 新增支付方式,选择 V免签,填写:
   - V免签地址(如 https://pay.example.com)
   - 通讯密钥(与 V免签后台一致)
   - 支付类型(1=微信 2=支付宝)
4. 在 V免签后台把“异步通知地址”设为:
   `https://你的面板域名/api/v1/guest/payment/notify/VmqPay/{支付方式uuid}`
   (uuid 在 Xboard 支付配置创建后可见;若 V免签 支持逐单 notifyUrl,插件已自动传入)

## 注意
- 回调为 GET,成功必须返回纯文本 `success`。
- 用户需按 V免签收银页显示的实付金额付款(尾数用于区分订单)。
- V免签订单默认 5 分钟过期,超时后重新点击支付会生成新的 payId。
