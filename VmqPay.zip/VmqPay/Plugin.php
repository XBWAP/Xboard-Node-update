<?php

namespace Plugin\VmqPay;

use App\Services\Plugin\AbstractPlugin;
use App\Contracts\PaymentInterface;
use App\Exceptions\ApiException;
use App\Models\Order;
use Illuminate\Support\Facades\Log;

class Plugin extends AbstractPlugin implements PaymentInterface
{
    public function boot(): void
    {
        $this->filter('available_payment_methods', function ($methods) {
            if ($this->getConfig('enabled', true)) {
                $methods['VmqPay'] = [
                    'name' => $this->getConfig('display_name', 'V免签'),
                    'icon' => $this->getConfig('icon', '💳'),
                    'plugin_code' => $this->getPluginCode(),
                    'type' => 'plugin'
                ];
            }
            return $methods;
        });
    }

    public function form(): array
    {
        return [
            'vmq_url' => [
                'label' => 'V免签地址',
                'type' => 'string',
                'required' => true,
                'description' => 'V免签服务端地址,如 https://pay.example.com(不要带结尾斜杠)'
            ],
            'vmq_key' => [
                'label' => '通讯密钥',
                'type' => 'string',
                'required' => true,
                'description' => 'V免签后台设置的通讯密钥,用于签名与验签'
            ],
            'pay_type' => [
                'label' => '支付类型',
                'type' => 'string',
                'required' => true,
                'description' => '填 1 = 微信,填 2 = 支付宝'
            ],
        ];
    }

    public function pay($order): array
    {
        try {
            $url = trim((string) $this->getConfig('vmq_url'));
            $key = (string) $this->getConfig('vmq_key');
            $type = (string) $this->getConfig('pay_type', '2');

            if ($url === '' || $key === '') {
                throw new \RuntimeException('V免签地址或通讯密钥未配置');
            }
            if (!in_array($type, ['1', '2'], true)) {
                throw new \RuntimeException('V免签支付类型只能是 1(微信) 或 2(支付宝)');
            }

            // payId 必须唯一:同一订单重复发起支付(如 V免签订单已超时)时需要新的 payId,
            // 真实订单号放在 param 中,回调时原样取回。
            $payId = $order['trade_no'] . 'T' . time();
            $param = (string) $order['trade_no'];
            // 金额(元),去掉多余的 0(10.00 -> 10,0.10 -> 0.1),与 V免签 文档示例的格式一致
            $price = rtrim(rtrim(number_format($order['total_amount'] / 100, 2, '.', ''), '0'), '.');
            $sign = md5($payId . $param . $type . $price . $key);

            $query = http_build_query([
                'payId' => $payId,
                'param' => $param,
                'type' => $type,
                'price' => $price,
                'sign' => $sign,
                'isHtml' => 1,
                'notifyUrl' => $order['notify_url'],  // 若 V免签 不支持逐单传入,则需在其后台设置异步通知地址
                'returnUrl' => $order['return_url'],
            ]);

            return [
                'type' => 1, // 跳转到 V免签 收银页(页面上会显示需实付的金额)
                'data' => rtrim($url, '/') . '/createOrder?' . $query,
            ];
        } catch (\Exception $e) {
            Log::error($e);
            throw new ApiException($e->getMessage());
        }
    }

    public function notify($params): array|bool
    {
        $key = (string) $this->getConfig('vmq_key');
        foreach (['payId', 'param', 'type', 'price', 'reallyPrice', 'sign'] as $field) {
            if (!isset($params[$field])) {
                Log::warning('VmqPay notify missing field: ' . $field);
                return false;
            }
        }

        $sign = md5($params['payId'] . $params['param'] . $params['type']
            . $params['price'] . $params['reallyPrice'] . $key);
        if (!hash_equals($sign, (string) $params['sign'])) {
            Log::warning('VmqPay notify bad sign', ['payId' => $params['payId']]);
            return false;
        }

        // 订单号从 param 取回,并校验订单存在、金额一致,防止伪造回调
        $tradeNo = (string) $params['param'];
        $order = Order::where('trade_no', $tradeNo)->first();
        if (!$order) {
            Log::warning('VmqPay notify order not found', ['trade_no' => $tradeNo]);
            return false;
        }
        $expected = number_format($order->total_amount / 100, 2, '.', '');
        if (!is_numeric($params['price']) || bccomp($expected, (string) $params['price'], 2) !== 0) {
            Log::warning('VmqPay notify amount mismatch', [
                'trade_no' => $tradeNo,
                'expected' => $expected,
                'price' => $params['price'],
            ]);
            return false;
        }

        return [
            'trade_no' => $tradeNo,
            'callback_no' => (string) $params['payId'],
        ];
    }
}
