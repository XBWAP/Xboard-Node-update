<?php

namespace Plugin\NotifyGateway\Support;

use App\Models\Payment;
use App\Models\Plan;
use App\Models\User;

/**
 * 把订单组装成推送的标题和正文。
 * 所有关联查询都包在 try/catch 里:查不到就省略对应行,绝不影响订单流程。
 */
class OrderMessageBuilder
{
    private const TYPE_LABELS = [
        1 => ['🆕', '新购'],
        2 => ['🔁', '续费'],
        3 => ['⬆️', '升级'],
        4 => ['🔄', '重置流量'],
    ];

    private const PERIOD_LABELS = [
        'month_price' => '月付',
        'quarter_price' => '季付',
        'half_year_price' => '半年付',
        'year_price' => '年付',
        'two_year_price' => '两年付',
        'three_year_price' => '三年付',
        'onetime_price' => '一次性',
        'reset_price' => '流量重置',
    ];

    /**
     * @return array{0:string,1:string} [标题, 正文]
     */
    public static function build($order, bool $showEmail = true, string $titlePrefix = ''): array
    {
        $type = (int) ($order->type ?? 0);
        [$emoji, $typeLabel] = self::TYPE_LABELS[$type] ?? ['🛒', '订单'];

        $title = trim($titlePrefix . ' ' . $emoji . ' ' . $typeLabel . ' ' . self::yuan($order->total_amount ?? 0));

        $lines = [];

        // 用户
        $userLine = '用户:#' . ($order->user_id ?? '?');
        try {
            if ($showEmail && ($user = User::find($order->user_id)) && !empty($user->email)) {
                $userLine = '用户:' . $user->email;
            }
        } catch (\Throwable $e) {
            // 忽略
        }
        $lines[] = $userLine;

        // 套餐 + 周期
        $planName = '未知套餐';
        try {
            if (!empty($order->plan_id) && ($plan = Plan::find($order->plan_id)) && !empty($plan->name)) {
                $planName = $plan->name;
            }
        } catch (\Throwable $e) {
            // 忽略
        }
        $period = (string) ($order->period ?? '');
        $periodLabel = self::PERIOD_LABELS[$period] ?? $period;
        $lines[] = '套餐:' . $planName . ($periodLabel !== '' ? '(' . $periodLabel . ')' : '');

        $lines[] = '类型:' . $typeLabel;
        $lines[] = '实付:' . self::yuan($order->total_amount ?? 0);

        // 抵扣明细:大于 0 才显示
        foreach ([
            'balance_amount' => '余额抵扣',
            'discount_amount' => '优惠券抵扣',
            'surplus_amount' => '升级折抵',
            'handling_amount' => '手续费',
        ] as $field => $label) {
            $value = (int) ($order->{$field} ?? 0);
            if ($value > 0) {
                $lines[] = $label . ':' . self::yuan($value);
            }
        }

        // 支付方式
        $paymentName = '余额/无需支付';
        try {
            if (!empty($order->payment_id) && ($payment = Payment::find($order->payment_id)) && !empty($payment->name)) {
                $paymentName = $payment->name;
            }
        } catch (\Throwable $e) {
            // 忽略
        }
        $lines[] = '支付方式:' . $paymentName;

        $lines[] = '订单号:' . ($order->trade_no ?? '-');
        if (!empty($order->callback_no)) {
            $lines[] = '回调单号:' . $order->callback_no;
        }
        $lines[] = '时间:' . now()->format('Y-m-d H:i:s');

        return [$title, implode("\n", $lines)];
    }

    /** 分 -> 元,格式 ¥30.00 */
    private static function yuan($cents): string
    {
        return '¥' . number_format(((int) $cents) / 100, 2, '.', '');
    }
}
