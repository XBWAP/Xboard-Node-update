<?php

namespace Plugin\NotifyGateway\Channels;

/**
 * 通知渠道接口。新增渠道只需实现本接口,并在 Plugin::channelMap() 中注册。
 */
interface ChannelInterface
{
    /** 渠道标识,对应后台“启用的渠道”中填写的名称(小写) */
    public static function name(): string;

    /** 必填配置是否齐全;不齐全的渠道会被跳过 */
    public function isConfigured(): bool;

    /**
     * 发送一条通知。
     *
     * @param string $title   标题
     * @param string $body    正文(纯文本)
     * @param array  $options 预留的附加选项
     * @return bool 是否发送成功(失败只返回 false,不要向外抛异常)
     */
    public function send(string $title, string $body, array $options = []): bool;
}
