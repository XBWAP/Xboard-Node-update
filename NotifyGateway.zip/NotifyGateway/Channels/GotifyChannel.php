<?php

namespace Plugin\NotifyGateway\Channels;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class GotifyChannel implements ChannelInterface
{
    /** @var array{server?:string,token?:string,priority?:string|int} */
    private array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public static function name(): string
    {
        return 'gotify';
    }

    private function server(): string
    {
        return rtrim(trim((string) ($this->config['server'] ?? '')), '/');
    }

    private function token(): string
    {
        return trim((string) ($this->config['token'] ?? ''));
    }

    public function isConfigured(): bool
    {
        return $this->server() !== '' && $this->token() !== '';
    }

    public function send(string $title, string $body, array $options = []): bool
    {
        try {
            $priority = (int) ($this->config['priority'] ?? 5);

            // token 放请求头而不是 URL,避免出现在异常信息或访问日志里
            $response = Http::timeout(5)
                ->connectTimeout(3)
                ->withHeaders(['X-Gotify-Key' => $this->token()])
                ->asJson()
                ->post($this->server() . '/message', [
                    'title' => $title,
                    'message' => $body,
                    'priority' => $priority,
                ]);

            if (!$response->successful()) {
                Log::warning('NotifyGateway[gotify] push failed', [
                    'status' => $response->status(),
                    'body' => mb_substr((string) $response->body(), 0, 200),
                ]);
                return false;
            }
            return true;
        } catch (\Throwable $e) {
            Log::warning('NotifyGateway[gotify] push error: ' . $e->getMessage());
            return false;
        }
    }
}
