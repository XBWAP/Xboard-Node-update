<?php

namespace Plugin\NotifyGateway\Channels;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class BarkChannel implements ChannelInterface
{
    /** @var array{server?:string,device_key?:string,group?:string,level?:string} */
    private array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public static function name(): string
    {
        return 'bark';
    }

    private function server(): string
    {
        return rtrim(trim((string) ($this->config['server'] ?? '')), '/');
    }

    /** @return string[] */
    private function deviceKeys(): array
    {
        $keys = array_map('trim', explode(',', (string) ($this->config['device_key'] ?? '')));
        return array_values(array_filter($keys, fn ($k) => $k !== ''));
    }

    public function isConfigured(): bool
    {
        return $this->server() !== '' && count($this->deviceKeys()) > 0;
    }

    public function send(string $title, string $body, array $options = []): bool
    {
        $allOk = true;

        foreach ($this->deviceKeys() as $key) {
            try {
                $payload = [
                    'device_key' => $key,
                    'title' => $title,
                    'body' => $body,
                    'group' => (string) ($this->config['group'] ?? 'Xboard'),
                    'level' => (string) ($this->config['level'] ?? 'active'),
                ];

                $response = Http::timeout(5)
                    ->connectTimeout(3)
                    ->asJson()
                    ->post($this->server() . '/push', $payload);

                $json = $response->json();
                $codeOk = !is_array($json) || !isset($json['code']) || (int) $json['code'] === 200;

                if (!$response->successful() || !$codeOk) {
                    $allOk = false;
                    Log::warning('NotifyGateway[bark] push failed', [
                        'status' => $response->status(),
                        'body' => mb_substr((string) $response->body(), 0, 200),
                    ]);
                }
            } catch (\Throwable $e) {
                $allOk = false;
                Log::warning('NotifyGateway[bark] push error: ' . $e->getMessage());
            }
        }

        return $allOk;
    }
}
