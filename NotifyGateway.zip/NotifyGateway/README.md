# NotifyGateway - Xboard 通知网关插件

把 Xboard 里的业务事件推送给**运营者**(你自己)。目前支持两个渠道:**Bark**(iOS)和 **Gotify**(自建推送服务),并且采用"渠道驱动"结构,后续新增渠道不需要改动业务代码。

当前事件:**用户成功购买套餐**(订单履行完成后推送)。

## 推送效果

```
标题: 🆕 新购 ¥30.00
正文:
用户:user@example.com
套餐:XXX 套餐(季付)
类型:新购
实付:¥30.00
优惠券抵扣:¥2.00
支付方式:V免签
订单号:2026xxxxxxxx
时间:2026-10-19 21:30:00
```

订单类型分为 🆕 新购、🔁 续费、⬆️ 升级、🔄 重置流量。余额抵扣、优惠券抵扣、升级折抵、手续费只有大于 0 才会出现。

## 安装

1. 将 `NotifyGateway/` 目录放入 Xboard 的 `plugins/` 下。
   Docker 部署请确认该目录已挂载,或已重建进镜像,否则容器重启后插件会丢失。
2. 后台 **插件管理** → 安装并启用 `NotifyGateway`。
3. 进入插件配置,按下表填写。

## 配置项

| 配置项 | 说明 | 默认 |
| --- | --- | --- |
| 启用通知 | 总开关 | 开 |
| 启用的渠道 | 逗号分隔:`bark`、`gotify`,如 `bark,gotify` | `bark` |
| 通知的订单类型 | `1`=新购 `2`=续费 `3`=升级 `4`=重置流量;只想收新购就填 `1` | `1,2,3,4` |
| 标题前缀 | 多站点时用来区分,如 `[MySite]` | 空 |
| 推送中显示用户邮箱 | 关闭则只显示用户 ID | 开 |
| Bark 服务器地址 | 官方 `https://api.day.app`,自建填自己的,不带结尾斜杠 | `https://api.day.app` |
| Bark Device Key | Bark App 首页显示的 key,多个设备用逗号分隔 | 空 |
| Bark 通知分组 | Bark App 内的分组名 | `Xboard` |
| Bark 通知级别 | `active` / `timeSensitive` / `passive` | `active` |
| Gotify 服务器地址 | 如 `https://gotify.example.com`,不带结尾斜杠 | 空 |
| Gotify 应用 Token | 在 Gotify 后台创建 Application 后获得 | 空 |
| Gotify 消息优先级 | 数字 | `5` |

渠道被启用但必填项没填全时,会被跳过并在日志里记录一条警告,不影响其他渠道。

## Bark 配置

1. 在 iPhone 安装 Bark,打开后首页会显示一个测试 URL:`https://api.day.app/<device_key>/...`,其中的 `<device_key>` 就是要填的值。
2. 使用官方服务器时地址保持默认;自建 bark-server 则填自己的地址。
3. 想让手机在专注模式下也提醒,可把通知级别改为 `timeSensitive`。

## Gotify 配置

1. 在 Gotify 后台 **Apps** 里创建一个 Application(如 `Xboard`),复制它的 token。
2. 服务器地址填你的 Gotify 访问地址。
3. 插件通过请求头 `X-Gotify-Key` 传递 token,不会出现在 URL 里。

## 工作原理

- 监听 Xboard 的 `order.open.after` 钩子,即订单**履行完成、用户套餐已生效**之后才触发。
- **推送不会影响订单**:整个流程包在 `try/catch` 里,每个请求超时 5 秒(连接 3 秒),失败只写日志。
- **渠道相互独立**:一个渠道失败不影响另一个。
- **防重复**:同一订单 24 小时内只推送一次;如果所有渠道都失败,会释放标记以便再次触发时重试。

## 验证推送是否正常

**方法一(最可靠)**:下一笔小额测试订单(余额支付也行),完成后手机应收到推送。

**方法二**:在面板目录用 `tinker` 对一笔已有订单手动触发钩子:

```bash
php artisan tinker
>>> \App\Services\Plugin\HookManager::call('order.open.after', [\App\Models\Order::latest()->first()]);
```

如果该订单之前已推送过,需要先清掉防重复标记:

```bash
>>> \Illuminate\Support\Facades\Cache::forget('notify_gateway:order:订单号');
```

`HookManager::call` 的参数形式以你面板里的源码为准,若报错请对照 `app/Services/Plugin/HookManager.php`。

## 排查

查看 Xboard 日志(`storage/logs`)里搜索 `NotifyGateway`:

| 日志 | 含义 |
| --- | --- |
| `unknown channel 'xxx'` | 渠道名写错,只支持 `bark`、`gotify` |
| `channel 'xxx' is enabled but not fully configured` | 该渠道必填项没填全 |
| `[bark] push failed` / `[gotify] push failed` | 服务器返回非成功,日志里有状态码和响应片段 |
| `push error: ...` | 网络错误或超时 |

## 新增一个渠道

1. 在 `Channels/` 下新建类,实现 `ChannelInterface`(`name()`、`isConfigured()`、`send()`)。
2. 在 `Plugin.php` 的 `channelMap()` 里加一行注册。
3. 在 `config.json` 的 `config` 里加该渠道的配置项。
4. 后台"启用的渠道"里填上新渠道名即可。

## 隐私与安全

- 推送会出现在手机锁屏上,不想暴露邮箱可以关闭"推送中显示用户邮箱"。
- Device Key 和 Token 是密钥,不要截图外传、不要提交进仓库。
- 插件不会把密钥写进日志。

## 已知限制

- 目前只有"购买套餐成功"一个事件,尚未包含工单、注册、节点离线等。
- 通知只发给运营者,不包含给用户推送(需要用户绑定自己的设备,不在本插件范围内)。
- 订单字段名按 Xboard 当前的 `Order` 模型编写,读取不到的字段会被省略而不会报错。
