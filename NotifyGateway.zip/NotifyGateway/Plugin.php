<?php

namespace Plugin\NotifyGateway;

use App\Services\Plugin\AbstractPlugin;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Plugin\NotifyGateway\Channels\BarkChannel;
use Plugin\NotifyGateway\Channels\ChannelInterface;
use Plugin\NotifyGateway\Channels\GotifyChannel;
use Plugin\NotifyGateway\Support\OrderMessageBuilder;

class Plugin extends AbstractPlugin
{
    public function boot(): void
    {
        // 订单履行完成(用户套餐已生效)之后触发
        $this->listen('order.open.after', function ($order) {
            $this->handleOrderOpened($order);
        });
    }

    /**
     * 渠道注册表:渠道名 => 构造该渠道的闭包。
     * 新增渠道时,在这里加一行即可(并新建对应的 Channel 类)。
     *
     * @return array<string, callable():ChannelInterface>
     */
    private function channelMap(): array
    {
        return [
            BarkChannel::name() => fn () => new BarkChannel([
                'server' => $this->getConfig('bark_server', 'https://api.day.app'),
                'device_key' => $this->getConfig('bark_device_key', ''),
                'group' => $this->getConfig('bark_group', 'Xboard'),
                'level' => $this->getConfig('bark_level', 'active'),
            ]),
            GotifyChannel::name() => fn () => new GotifyChannel([
                'server' => $this->getConfig('gotify_server', ''),
                'token' => $this->getConfig('gotify_token', ''),
                'priority' => $this->getConfig('gotify_priority', '5'),
            ]),
        ];
    }

    private function flag(string $key, bool $default): bool
    {
        $value = $this->getConfig($key, $default);
        if (is_bool($value)) {
            return $value;
        }
        return in_array(strtolower(trim((string) $value)), ['1', 'true', 'yes', 'on'], true);
    }

    /** @return string[] */
    private function csv(string $key, string $default): array
    {
        $raw = (string) $this->getConfig($key, $default);
        $items = array_map(fn ($s) => strtolower(trim($s)), explode(',', $raw));
        return array_values(array_filter($items, fn ($s) => $s !== ''));
    }

    /**
     * 按“启用的渠道”配置实例化渠道,忽略未知渠道名与配置不全的渠道。
     *
     * @return array<string, ChannelInterface>
     */
    private function activeChannels(): array
    {
        $map = $this->channelMap();
        $active = [];

        foreach ($this->csv('channels', 'bark') as $name) {
            if (!isset($map[$name])) {
                Log::warning("NotifyGateway: unknown channel '{$name}'");
                continue;
            }
            $channel = $map[$name]();
            if (!$channel->isConfigured()) {
                Log::warning("NotifyGateway: channel '{$name}' is enabled but not fully configured");
                continue;
            }
            $active[$name] = $channel;
        }

        return $active;
    }

    private function handleOrderOpened($order): void
    {
        // 整个流程包在 try/catch 里:通知失败绝不能影响订单履行
        try {
            if (!$this->flag('enabled', true)) {
                return;
            }

            $allowedTypes = $this->csv('notify_types', '1,2,3,4');
            if (!in_array((string) ($order->type ?? ''), $allowedTypes, true)) {
                return;
            }

            $channels = $this->activeChannels();
            if (!$channels) {
                return;
            }

            // 防重复:同一订单 24 小时内只推送一次
            $dedupKey = 'notify_gateway:order:' . ($order->trade_no ?? ($order->id ?? ''));
            if (!Cache::add($dedupKey, 1, 86400)) {
                return;
            }

            [$title, $body] = OrderMessageBuilder::build(
                $order,
                $this->flag('show_email', true),
                trim((string) $this->getConfig('title_prefix', ''))
            );

            $anySuccess = false;
            foreach ($channels as $name => $channel) {
                try {
                    if ($channel->send($title, $body)) {
                        $anySuccess = true;
                    }
                } catch (\Throwable $e) {
                    Log::warning("NotifyGateway[{$name}] unexpected error: " . $e->getMessage());
                }
            }

            // 所有渠道都失败时释放去重标记,允许该订单事件再次触发时重试
            if (!$anySuccess) {
                Cache::forget($dedupKey);
            }
        } catch (\Throwable $e) {
            Log::error('NotifyGateway: ' . $e->getMessage());
        }
    }
}
